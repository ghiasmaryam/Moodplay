package com.music.moodplay.models.pulseRateModels

import java.util.*

class Measurement<T>(val timestamp: Date, val measurement: T)