package com.music.moodplay.models.firebaseModels

class FSPulseRatesModel {

    var highest: Int = 0
    var lowest: Int = 0
    var moodType: String = ""

}