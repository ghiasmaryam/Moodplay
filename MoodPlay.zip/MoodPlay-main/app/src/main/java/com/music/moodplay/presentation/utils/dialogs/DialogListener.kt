package com.music.moodplay.presentation.utils.dialogs

interface DialogListener {
    fun onPositiveClick()
    fun onNegativeClick()
}